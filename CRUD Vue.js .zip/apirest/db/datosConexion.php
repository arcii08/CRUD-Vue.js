<?php
    $db = ['servidor' => 'localhost','usuario' => 'root', 'password' => '','db' => 'articulosdb'];
