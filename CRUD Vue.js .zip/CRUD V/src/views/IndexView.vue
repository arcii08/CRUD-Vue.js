<template>

<v-row class="text-center">    
      <v-col class="">
        <h1 class="display-3 font-weight-bold ">Formulario de articulos</h1>       
      </v-col>     
    </v-row>
    <v-row>
    <v-col class="pb-8">
        <v-card class="mx-auto px-6 pt-8" max-width="944">
        <form v-on:submit.prevent="guardarArticulo()">
        <v-text-field v-model="articulo.descripcion"
                label="Descripción"
                outlined
                required   
        >
        </v-text-field>
         <v-text-field
                v-model="articulo.precio"        
                label="Precio"
                type="number"                
                prefix="€"
                outlined
                required        
            ></v-text-field>
            <v-text-field
                v-model="articulo.stock"        
                label="Stock"
                type="number"
                outlined
                required        
            ></v-text-field>
            <v-card-actions>
                <v-btn color="warning" class="mr-4" type="submit">Guardar</v-btn>      
            </v-card-actions>
        </form>
        </v-card>
    </v-col>
    </v-row>

    <v-sheet class="bg bg-teal-lighten-4 pa-12" rounded>
        <v-table fixed-header height="300px" rounded>
            <thead>
                <tr>
                    <th class="text-center">
                        Id
                    </th>
                    <th class="text-center">
                        Descripcion
                    </th>
                    <th class="text-center">
                        Precio
                    </th>
                    <th class="text-center">
                        Stock
                    </th>
                    <th class="text-center">
                        Acciones
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="item in articulos" :key="item.id">
                    <td class="text-center">{{ item.id }}</td>
                    <td class="text-center">{{ item.descripcion }}</td>
                    <td class="text-center">{{ item.precio }} €</td>
                    <td class="text-center">{{ item.stock }}</td>
                    <td class="text-center"> <v-btn :to="{name:'editarArticulo', params:{id:item.id}}" icon="mdi-pencil-outline" variant="text"></v-btn>
                        <v-btn @click.stop="dialog=true" @click="id=item.id" icon="mdi-delete-empty" variant="text"></v-btn>
                    </td>
                </tr>
            </tbody>
        </v-table>
    </v-sheet>
    <v-dialog v-model="dialog" max-width="350">
        <v-card>
            <v-card-title class="headline">¿Desea eliminar el registro?</v-card-title>
            <v-card-actions>
            <v-spacer></v-spacer>
                <v-btn @click="dialog = false">Cancelar</v-btn>
                <v-btn @click="confirmarBorrado(id)" color="error">Aceptar</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
    <!-- componente snackbar para mostrar mensaje de eliminación -->
    <v-snackbar v-model="snackbar" color="success"> {{textsnack}}
        <template v-slot:action="{attrs}">
            <v-btn text v-bind="attrs" @click="snackbar = false">Cerrar</v-btn>
        </template>
    </v-snackbar>
</template>
<script>
import axios from 'axios';
import { routerKey } from 'vue-router';

export default {
    name:'listarArticulos',
    mounted(){
        this.obtenerArticulos();
    },
    data(){
        return{      
            articulo:{
                descripcion:'',
                precio:'',
                stock:''
            },
            
            dialog:false,
            articulos:null,
            id:null,
            snackbar:false,
            textsnack:'¡Registro Eliminado!'
        }
    },
    methods:{
        obtenerArticulos(){
            axios.get('http://localhost/apirest/articulos.php')
            .then(r => {
                this.articulos = r.data;
                console.log(this.articulos);
            })
            .catch(function(error){
                console.log(error);
            })

        },
        confirmarBorrado(id){            
            axios.delete('http://localhost/apirest/articulos.php?id='+id)
            .then(()=>{
                    this.obtenerArticulos();
                    this.dialog = false;
                    this.snackbar = true
            })
            .catch(function(error){
                console.log(error);
            });    
        },
        guardarArticulo(){
            var router = this.$router;
           const formData = new FormData();
           formData.append('descripcion',this.articulo.descripcion);
           formData.append('precio',this.articulo.precio);
           formData.append('stock',this.articulo.stock);
           axios.post('http://localhost/apirest/articulos.php',formData)
           .then(()=>{

            window.location.reload();
               router.push('/index');
           })
           .catch(function(error){
        console.log(error);
            });
        }
     
    }
}
</script>
