<template>
  <v-sheet class="bg pa-12" rounded>
    <v-card class="rounded-lg mx-auto px-6 py-8" max-width="414" max-height="600">
      
      <v-form v-model="form" @submit.prevent="onSubmit">
        <v-text-field v-model="email" :readonly="loading" :rules="[required]" class="mb-2" clearable
          label="Email"></v-text-field>

        <v-text-field v-model="password" :readonly="loading" :rules="[required]" clearable label="Contraseña"
          placeholder="Introduce tu contraseña"></v-text-field>

        <br>

        <v-btn :disabled="!form" :loading="loading" block color="success" size="large" type="submit" variant="elevated" @click="log">
          Iniciar sesión
        </v-btn>
      </v-form>
    </v-card>
  </v-sheet>
</template>

<script>
export default {
  data: () => ({

    usuarios:[
      {
        email:'jorge@jorge.com',
        password:'1234'
      },
      {
        email:'carlos@carlos.com',
        password:'5678'
      }
    ],

    form: false,
    email: null,
    password: null,
    loading: false,
  }),

  methods: {

    log: function () {
      this.$router.push("/index");
    },

    onSubmit() {
      if (!this.form) return

      this.loading = true

      setTimeout(() => (this.loading = false), 2000)
    },
    required(v) {
      return !!v || 'Campo requerido'
    },
  },
}
</script>

<style>
@import url('../assets/bootstrap.css');
</style>
