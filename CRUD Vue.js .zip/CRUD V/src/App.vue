<template>
  <div>
    <v-toolbar
      dark
      prominent
      
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title>CRUD Vuetify</v-toolbar-title>

     <v-btn @click="pasar" class="btn btn-outline-success">Iniciar sesión</v-btn>

      <v-spacer></v-spacer>

     

      <v-btn icon @click="pasar">
        <v-icon>mdi-export</v-icon>
      </v-btn>
    </v-toolbar>
  </div>

  <router-view />
</template>

<!--
<template>


  <v-app>
    <v-main>
      <RouterLink to="/">Home</RouterLink>
      <RouterLink to="/about">About</RouterLink>
      <button @click="pasar" class="btn btn-outline-success">Pasar a about</button>
 
      <router-view />
    </v-main>
  </v-app>
</template>-->

<script>

import { RouterLink, RouterView } from 'vue-router'



export default {
  methods: {
    pasar: function () {
      this.$router.push("/about");
    }
  }
}


/*export default {
  name: 'App',

  data: () => ({
    //
  }),
}*/
</script>

